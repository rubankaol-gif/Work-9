function sendJson(res, statusCode, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function sendNoContent(res) {
  res.writeHead(204);
  res.end();
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';

    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1_000_000) {
        reject(new Error('Request body is too large'));
        req.destroy();
      }
    });

    req.on('end', () => {
      if (!body.trim()) {
        resolve({});
        return;
      }

      try {
        resolve(JSON.parse(body));
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });

    req.on('error', reject);
  });
}

function isCollectionPath(pathname) {
  return pathname === '/items' || pathname === '/api/items' || pathname === '/records' || pathname === '/data';
}

function getIdFromPath(pathname) {
  const match = pathname.match(/^\/(?:items|api\/items|records|data)\/(\d+)$/);
  return match ? Number(match[1]) : null;
}

module.exports = { sendJson, sendNoContent, readJsonBody, isCollectionPath, getIdFromPath };
