const fs = require('fs/promises');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', 'data', 'data.json');

async function readItems() {
  try {
    const raw = await fs.readFile(DATA_FILE, 'utf8');
    const items = JSON.parse(raw || '[]');
    return Array.isArray(items) ? items : [];
  } catch (error) {
    if (error.code === 'ENOENT') {
      await writeItems([]);
      return [];
    }
    throw error;
  }
}

async function writeItems(items) {
  await fs.writeFile(DATA_FILE, JSON.stringify(items, null, 2), 'utf8');
}

function getNextId(items) {
  const maxId = items.reduce((max, item) => {
    const numericId = Number(item.id);
    return Number.isFinite(numericId) && numericId > max ? numericId : max;
  }, 0);
  return maxId + 1;
}

module.exports = { readItems, writeItems, getNextId };
