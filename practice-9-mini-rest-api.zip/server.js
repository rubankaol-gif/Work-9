const http = require('http');
const { readItems, writeItems, getNextId } = require('./src/storage');
const { sendJson, sendNoContent, readJsonBody, isCollectionPath, getIdFromPath } = require('./src/helpers');

async function handleRequest(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;
  const method = req.method;

  try {
    if (method === 'GET' && pathname === '/') {
      return sendJson(res, 200, {
        message: 'Practice 9 - Mini REST API on pure Node.js',
        endpoints: [
          'GET /items',
          'GET /items/:id',
          'POST /items',
          'PUT /items/:id',
          'PATCH /items/:id',
          'DELETE /items/:id'
        ]
      });
    }

    if (method === 'GET' && isCollectionPath(pathname)) {
      const items = await readItems();
      return sendJson(res, 200, items);
    }

    const id = getIdFromPath(pathname);

    if (method === 'GET' && id !== null) {
      const items = await readItems();
      const item = items.find(record => Number(record.id) === id);

      if (!item) {
        return sendJson(res, 404, { error: 'Resource not found' });
      }

      return sendJson(res, 200, item);
    }

    if (method === 'POST' && isCollectionPath(pathname)) {
      const body = await readJsonBody(req);

      if (!body || typeof body !== 'object' || Array.isArray(body)) {
        return sendJson(res, 400, { error: 'JSON object is required' });
      }

      if (typeof body.name !== 'string' || body.name.trim() === '') {
        return sendJson(res, 422, { error: 'Field "name" is required and must be a non-empty string' });
      }

      const items = await readItems();
      const newItem = {
        id: getNextId(items),
        ...body,
        name: body.name.trim()
      };

      items.push(newItem);
      await writeItems(items);

      return sendJson(res, 201, newItem);
    }

    if ((method === 'PUT' || method === 'PATCH') && id !== null) {
      const body = await readJsonBody(req);

      if (!body || typeof body !== 'object' || Array.isArray(body)) {
        return sendJson(res, 400, { error: 'JSON object is required' });
      }

      const items = await readItems();
      const index = items.findIndex(record => Number(record.id) === id);

      if (index === -1) {
        return sendJson(res, 404, { error: 'Resource not found' });
      }

      if (method === 'PUT' && (typeof body.name !== 'string' || body.name.trim() === '')) {
        return sendJson(res, 422, { error: 'Field "name" is required for full update' });
      }

      const updatedItem = {
        ...(method === 'PATCH' ? items[index] : {}),
        ...body,
        id
      };

      if (typeof updatedItem.name === 'string') {
        updatedItem.name = updatedItem.name.trim();
      }

      items[index] = updatedItem;
      await writeItems(items);

      return sendJson(res, 200, updatedItem);
    }

    if (method === 'DELETE' && id !== null) {
      const items = await readItems();
      const exists = items.some(record => Number(record.id) === id);

      if (!exists) {
        return sendJson(res, 404, { error: 'Resource not found' });
      }

      const filteredItems = items.filter(record => Number(record.id) !== id);
      await writeItems(filteredItems);

      return sendNoContent(res);
    }

    return sendJson(res, 404, { error: 'Not found' });
  } catch (error) {
    const statusCode = error.message === 'Invalid JSON' ? 400 : 500;
    return sendJson(res, statusCode, { error: error.message || 'Internal server error' });
  }
}

function createServer() {
  return http.createServer(handleRequest);
}

if (require.main === module) {
  const port = Number(process.argv[2]) || 3000;
  createServer().listen(port, () => {
    console.log(`Mini REST API is running on http://localhost:${port}`);
  });
}

module.exports = { createServer, handleRequest };
