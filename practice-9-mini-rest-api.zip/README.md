# Practice 9 - Mini REST API (Pure Node.js)

Виконав: Рубанка Олександр, група 223 Он

## Мета роботи

Навчитися будувати простий REST API на чистому Node.js без фреймворків: читати колекцію з `data.json`, отримувати ресурс за `id`, створювати нові записи, оновлювати існуючі та видаляти їх з файлу.

## Як запустити

```bash
node server.js 3000
```

Після запуску API буде доступне за адресою:

```text
http://localhost:3000
```

## Виконані вправи

- 9.1 — читання колекції з `data/data.json`.
- 9.2 — отримання одного ресурсу за `id`.
- 9.3 — створення нового запису через `POST`.
- 9.4 — оновлення існуючого запису через `PUT` або `PATCH`.
- 9.5 — видалення запису через `DELETE`.

## Основні endpoints

### Перевірка API

```bash
curl http://localhost:3000/
```

### Отримати всю колекцію

```bash
curl http://localhost:3000/items
```

### Отримати ресурс за id

```bash
curl http://localhost:3000/items/1
```

### Створити новий запис

```bash
curl -X POST http://localhost:3000/items ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Petro\",\"age\":23,\"course\":\"Node.js\"}"
```

Для PowerShell можна використати:

```powershell
Invoke-RestMethod -Method Post -Uri "http://localhost:3000/items" -ContentType "application/json" -Body '{"name":"Petro","age":23,"course":"Node.js"}'
```

### Оновити запис повністю

```bash
curl -X PUT http://localhost:3000/items/1 ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Ivan Updated\",\"age\":21,\"course\":\"REST API\"}"
```

### Частково оновити запис

```bash
curl -X PATCH http://localhost:3000/items/1 ^
  -H "Content-Type: application/json" ^
  -d "{\"course\":\"Updated course\"}"
```

### Видалити запис

```bash
curl -X DELETE http://localhost:3000/items/1
```

## Логіка роботи

У роботі використано тільки вбудовані модулі Node.js:

- `http` — створення сервера;
- `fs/promises` — читання та запис файлу `data.json`;
- `path` — побудова шляху до файлу з даними.

Фреймворки типу Express не використовуються. Роутинг реалізований вручну через перевірку `method + pathname`.

## Обробка помилок

API повертає коректні статус-коди:

- `200 OK` — успішне читання або оновлення;
- `201 Created` — успішне створення нового запису;
- `204 No Content` — успішне видалення;
- `400 Bad Request` — неправильний JSON;
- `404 Not Found` — маршрут або ресурс не знайдено;
- `422 Unprocessable Entity` — неправильна структура даних;
- `500 Internal Server Error` — внутрішня помилка сервера.
